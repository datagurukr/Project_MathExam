package com.danalpay.credit.sample.danalpaycardsample;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.net.URISyntaxException;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private WebView webView = null;
    private final Handler handler = new Handler();

    public static final String TAG = "DanalPayCardSample";
    public static final String APPSCHEME = "danalpaycardsample://";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = (WebView) findViewById(R.id.webview);

        webView.getSettings().setSavePassword(false);
        webView.getSettings().setAppCacheEnabled(true);

        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.addJavascriptInterface(new DanalCreditBridge(), "DanalCreditApp");
        webView.getSettings().setUseWideViewPort(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new mWebViewClient());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            WebSettings webViewSettings = webView.getSettings();
            webViewSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

	    CookieManager cookieManager = CookieManager.getInstance();
            cookieManager.setAcceptCookie(true);
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }

        webView.loadUrl("http://가맹점웹서버/Order.jsp");


        /*
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }
        */
    }

    private class mWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {

            Log.d(TAG, "called__shouldOverrideUrlLoading - url=[" + url + "]");

            if (url != null && !url.equals("about:blank")) {
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    if (url.contains("http://market.android.com") ||
                            url.contains("http://m.ahnlab.com/kr/site/download") ||
                            url.endsWith(".apk")) {
                        return urlSchemeProc(view, url);
                    } else {
                        view.loadUrl(url);
                        return false;
                    }
                } else if (url.startsWith("mailto:")) {
                    return false;
                } else if (url.startsWith("tel:")) {
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
                    startActivity(intent);
                    return true;
                } else {
                    return urlSchemeProc(view, url);
                }
            }
            return true;
        }
    }

    private class DanalCreditBridge {

        @JavascriptInterface
        public void runISP(final String argUrl, final String packageName) {
            handler.post(new Runnable() {
                public void run() {
                    boolean install = true;
                    String strUrl;

                    PackageManager packMgr = getPackageManager();
                    List<ApplicationInfo> installedAppList = packMgr.getInstalledApplications(PackageManager.GET_UNINSTALLED_PACKAGES);

                    for (ApplicationInfo appInfo : installedAppList) {
                        if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                            if (appInfo.packageName.indexOf(packageName) > -1) {
                                install = false;
                                break;
                            }
                        }
                    }

                    strUrl = (install == true)
                            ? "market://details?id=" + packageName
                            : argUrl;

                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(strUrl));
                    startActivity(intent);
                }
            });
        }
    }

    private boolean urlSchemeProc(WebView view, String url) {

        if (url != null &&
                (
                        url.contains("cloudpay")
                                || url.contains("hanaansim")
                                || url.contains("citispayapp")
                                || url.contains("citicardapp")
                                || url.contains("mvaccine")
                                || url.contains("com.TouchEn.mVaccine.webs")
                                || url.contains("market://")
                                || url.contains("smartpay")	
                                || url.contains("com.ahnlab.v3mobileplus")
                                || url.contains("droidxantivirus")
                                || url.contains("v3mobile")
                                || url.endsWith(".apk")
                                || url.contains("market://")
                                || url.contains("ansimclick")
                                || url.contains("market://details?id=com.shcard.smartpay")
                                || url.contains("shinhan-sr-ansimclick://")
                                || url.contains("http://m.ahnlab.com/kr/site/download")
                                || url.contains("com.lotte.lottesmartpay")
                                || url.startsWith("lottesmartpay://")
                                || url.contains("http://market.android.com")
                                || url.contains("vguard")
                                || url.contains("smhyundaiansimclick://")
                                || url.contains("smshinhanansimclick://")
                                || url.contains("smshinhancardusim://")
                                || url.contains("smartwall://")
                                || url.contains("appfree://")
                                || url.startsWith("kb-acp://")
                                || url.startsWith("intent://")
                                || url.startsWith("ahnlabv3mobileplus")

                                || url.contains("smhyundaiansimclick")
                                || url.contains("smshinhanansimclick")
                                || url.contains("shinhan-sr-ansimclick")
                                || url.contains("vguardstart")
                                || url.contains("vguardend")
                                || url.contains("droidx3host")
                                || url.contains("mpocket.online.ansimclick")
                                || url.contains("hdcardappcardansimclick")
                                || url.contains("nhappcardansimclick")
                                || url.contains("nonghyupcardansimclick")
                                || url.contains("tswansimclick")
                                || url.contains("payco")
                                || url.contains("samsungpay")

                                //2017.07.31 하나 은행 추가 내용,
                                //하나카드 요청 내용
                                //① 안드로이드 : "bhcs://cardpotal.hanaskcard.com"
                                //② 마켓 연결 및 패키지명 : market://details?id=com.hanaskcard.rocomo.potal
                                || url.contains("hhcs") || url.contains("bhcs")
                            )) {
            try {
                Intent intent = null;
                try {
                    intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                    Log.i(TAG, "intent getScheme +++===>" + intent.getScheme());
                    Log.i(TAG, "intent getDataString +++===>" + intent.getDataString());
                } catch (URISyntaxException ex) {
                    Log.e("Browser", "Bad URI " + url + ":" + ex.getMessage());
                    return false;
                }
                //chrome 버젼 방식 : 2014.01 추가
                if (url.startsWith("intent")) { // chrome 버젼 방식
                    // 앱설치 체크를 합니다.
                    if (getPackageManager().resolveActivity(intent, 0) == null) {
                        String packagename = intent.getPackage();
                        if (packagename != null) {
                            Uri uri = Uri.parse("market://search?q=pname:" + packagename);
                            intent = new Intent(Intent.ACTION_VIEW, uri);
                            startActivity(intent);
                            return true;
                        }
                    }

                    Uri uri = Uri.parse(intent.getDataString());
                    intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);

                } else { // 구 방식
                    // 2017-08-04 하나카드 추가 내용 적용
                    if (url.startsWith("bhcs")) {
                        String packageName = "com.hanaskcard.rocomo.potal";
                        String appUrl = "bhcs://cardpotal.hanaskcard.com";
                        String marKet = "market://details?id=com.hanaskcard.rocomo.potal";

                        PackageManager pm = getPackageManager();
                        PackageInfo info = null;
                        try {
                            info = pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
                        } catch (Exception e) {
                            return false;
                        }
                        try {
                            if (info != null) {
                                Uri uri;
                                if(url.contains(appUrl)){
                                    uri = Uri.parse(url);
                                }else{
                                    uri = Uri.parse(appUrl);
                                }

                                Intent hanaIntent = new Intent(Intent.ACTION_VIEW, uri);
                                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                                startActivity(hanaIntent);
                            }else{
                                Uri uri = Uri.parse(marKet);
                                Intent hanaIntent = new Intent(Intent.ACTION_VIEW, uri);
                                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                                startActivity(hanaIntent);
                            }
                        } catch (Exception e) {
                            return false;
                        }

                    }else{
                        Uri uri = Uri.parse(url);
                        intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                    }
                }
            } catch (ActivityNotFoundException e) {
                Log.e("error ===>", e.getMessage());
                e.printStackTrace();
                if (url.startsWith("vguardend://")) {
                    return true;
                }else{
                    return false;
                }
            }
        } else {
            view.loadUrl(url);
            return false;
        }
        return true;
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {

            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setMessage(R.string.exit_app_message);
            dialog.setCancelable(true);
            dialog.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            dialog.setNegativeButton(android.R.string.cancel, null);
            dialog.show();

            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}

