package com.danalpay.credit.sample.danalpaycardsample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class ResultRcvActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.e(MainActivity.TAG, "[ResultRcvActivity] called__onCreate");

        Intent intent = getIntent();

        if (intent.getData().getScheme().equals(MainActivity.APPSCHEME)) {


            Log.e( MainActivity.TAG,
                    "[ResultRcvActivity] launch_uri=[" + intent.getData().toString() + "]" );

            finish();
        }

    }
}
