//
//  AppDelegate.m
//  DanalPaycard
//
//  Created by 오동현 on 2016. 1. 15..
//  Copyright © 2016년 오동현. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [self cookieSetting];
    
    return YES;
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    
    [self saveCookies];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    
    [self saveCookies];
}

/**
 * 앱 전역 쿠키 설정
 */
- (void)cookieSetting
{
    // 공용쿠키 설정
    NSHTTPCookieStorage *cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    [cookieStorage setCookieAcceptPolicy:NSHTTPCookieAcceptPolicyAlways];
    
    // 기존에 쿠키를 저장한 내역이 있다면,
    NSData *cookiesData = [[NSUserDefaults standardUserDefaults] objectForKey:@"SavedCookies"];
    
    if ([cookiesData length])
    {
        NSArray *cookies = [NSKeyedUnarchiver unarchiveObjectWithData:cookiesData];
        NSHTTPCookie *cookie;
        
        for (cookie in cookies)
        {
            [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
        }
    }
    
    NSLog(@"Perist Web Cookie Set!");
}

/**
 * 쿠키 저장
 */
- (void)saveCookies
{
    NSArray *cookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies];
    NSData *cookieData = [NSKeyedArchiver archivedDataWithRootObject:cookies];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:cookieData forKey:@"SavedCookies"];
    [defaults synchronize];
    
    NSLog(@"Cookie Saved!");
}

@end
