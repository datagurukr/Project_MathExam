//
//  ViewController.h
//  DanalPaycard
//
//  Created by 오동현 on 2016. 1. 15..
//  Copyright © 2016년 오동현. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (NSString *)storeIdFromLink:(NSString *)linkStr;
- (void)goItunesStoreWithLink:(NSString *)link;

@end

