//
//  ViewController.m
//  DanalPaycard
//
//  Created by 오동현 on 2016. 1. 15..
//  Copyright © 2016년 오동현. All rights reserved.
//

#import "ViewController.h"

#warning 해당 페이지 주소로 변경하세요
#define PAY_SERVER_URL @"결제페이지주소"


@interface ViewController () <UIWebViewDelegate>

@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:PAY_SERVER_URL]];
    [self.webView loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

#pragma mark - Webview Delegate



/**
 * 웹페이지 리퀘스트 요청 시작
 */
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    UIDevice* device = [UIDevice currentDevice];
    BOOL backgroundSupported = NO;
    if ([device respondsToSelector:@selector(isMultitaskingSupported)])
    {
        backgroundSupported = device.multitaskingSupported;
    }
    NSLog(@" backgroundSupported ==>%@",(backgroundSupported?@"YES":@"NO"));
    if (!backgroundSupported)
    {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"안 내" message:@"멀티테스킹을 지원하는 기기 또는 어플만 공인인증서비스가 가능합니다." preferredStyle:UIAlertControllerStyleAlert];
            
            
            [alertController addAction:[UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                
            }]];
            
            
            [[[[UIApplication sharedApplication] keyWindow] rootViewController] presentViewController:alertController animated:YES completion:^{
            }];
        });
        
        
        
      
      return YES;
    }
    
    
    
    
    NSURL    *requestedURL = [request URL];
    NSString *receivedLink = requestedURL.absoluteString;
    NSString *tempScheme = [requestedURL scheme];
    
    NSLog(@"Should Request::: %@", receivedLink);
    NSLog(@"scheme %@", [requestedURL scheme]);
    
    if( [receivedLink rangeOfString:@"about:blank"].location != NSNotFound )
    {
        return NO;
    }
    
    if( NO == [[UIApplication sharedApplication] canOpenURL:requestedURL])
    {
        
        [self checkScheme:tempScheme];
        return NO;
    }
    
    if( [receivedLink rangeOfString:@"http://103.11.131.186/creditcard_client_demo/back"].location != NSNotFound )
    {
        NSURLRequest *request = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:PAY_SERVER_URL]];
        [self.webView loadRequest:request];
        return NO;
    }
    
    if ([receivedLink rangeOfString:@"ansimclick.hyundaicard.com"].location !=NSNotFound)
    { }
    else
    {
        if ([receivedLink rangeOfString:@"http://itunes.apple.com"].location !=NSNotFound)
        {
            NSLog(@"1. 앱설치 url 입니다. ==>%@",receivedLink);
            [[UIApplication sharedApplication] openURL:requestedURL];
            return NO;
        }
        if ([receivedLink rangeOfString:@"ansimclick"].location !=NSNotFound)
        {
            NSLog(@" 앱 url 입니다. ==>%@",receivedLink);
            [[UIApplication sharedApplication] openURL:requestedURL];
            return NO;
        }
        if ([receivedLink rangeOfString:@"appfree"].location !=NSNotFound)
        {
            NSLog(@" 앱 url 입니다. ==>%@",receivedLink);
            [[UIApplication sharedApplication] openURL:requestedURL];
            return NO;
        }
    }
    // 앱카드 등록 확인 및 이동 - 하나은행 모비패이 앱카드
    if ([receivedLink isEqualToString:@"http://itunes.apple.com/app/id847268987"])
    {
        [self goItunesStoreWithLink:receivedLink];
        return NO;
    }
    
    // 앱카드 등록 확인 및 이동 - 국민 앱카드
    if ([receivedLink isEqualToString:@"https://itunes.apple.com/kr/app/kbgugmin-aebkadue/id695436326?mt=8"])
    {
        [self goItunesStoreWithLink:receivedLink];
        return NO;
    }
    
    // 앱카드 등록 확인 및 이동 - 농협 앱카드
    if ([receivedLink isEqualToString:@"http://itunes.apple.com/kr/app/nhnonghyeob-mobailkadeu-aebkadeu/id698023004?mt=8"])
    {
        [self goItunesStoreWithLink:receivedLink];
        return NO;
    }
    
    // 국민카드 앱 호출
    if ([[requestedURL scheme] isEqualToString:@"kb-acp"])
    {
        if ([[UIApplication sharedApplication] canOpenURL:requestedURL])
        {
            [[UIApplication sharedApplication] openURL:requestedURL];
        }
        return NO;
    }
    
    return YES;
}


#pragma mark - Logic

/**
 scheme 값 으로 앱 설치 유도

 @param scheme 실행 할 수 없는 앱의 scheme 값
 */
- (void) checkScheme:(NSString*) scheme
{
    BOOL tempIsKnownInstallUrl = NO;
    NSString *tempInstallUrl = nil;
    
    if( [scheme isEqualToString:@"cloudpay"] )
    {
        tempIsKnownInstallUrl = YES;
        tempInstallUrl = @"http://itunes.apple.com/app/id847268987";
    }
    else if( [scheme isEqualToString:@"shinhan-sr-ansimclick"] )
    {
        tempIsKnownInstallUrl = YES;
        tempInstallUrl = @"https://itunes.apple.com/kr/app/sinhan-mobilegyeolje/id572462317?mt=8";
    }
    else if( [scheme isEqualToString:@"ispmobile"] )
    {
        tempIsKnownInstallUrl = YES;
        tempInstallUrl = @"http://itunes.apple.com/kr/app/id369125087?mt=8";
    }
    else if( [scheme isEqualToString:@"kb-acp"] )
    {
        tempIsKnownInstallUrl = YES;
        tempInstallUrl = @"https://itunes.apple.com/kr/app/kbgugmin-aebkadue/id695436326?mt=8";
    }
    else if( [scheme isEqualToString:@"hdcardappcardansimclick"] )
    {
        tempIsKnownInstallUrl = YES;
        tempInstallUrl = @"http://itunes.apple.com/kr/app/id702653088?mt=8";
    }
    else if( [scheme isEqualToString:@"mpocket.online.ansimclick"] )
    {
        tempIsKnownInstallUrl = YES;
        tempInstallUrl = @"https://itunes.apple.com/kr/app/mpokes/id535125356?mt=8&ls=1";
    }
    else if( [scheme isEqualToString:@"lotteappcard"] )
    {
        tempIsKnownInstallUrl = YES;
        tempInstallUrl = @"https://itunes.apple.com/kr/app/losde-aebkadeu/id688047200?mt=8";
    }
    else if( [scheme isEqualToString:@"nhallonepayansimclick"] )
    {
        tempIsKnownInstallUrl = YES;
        tempInstallUrl = @"https://itunes.apple.com/kr/app/id1177889176?mt=8";
    }
    else if( [scheme isEqualToString:@"citispay"] )
    {
        tempIsKnownInstallUrl = YES;
        tempInstallUrl = @"https://itunes.apple.com/kr/app/citi-cards-mobile-ssitikadeu/id373559493?l=en&mt=8";
    }
    else if( [scheme isEqualToString:@"payco"] )
    {
        tempIsKnownInstallUrl = YES;
        tempInstallUrl = @"https://itunes.apple.com/kr/app/id924292102";
    }
    else if( [scheme isEqualToString:@"tswansimclick"] )
    {
        tempIsKnownInstallUrl = YES;
        tempInstallUrl = @"https://itunes.apple.com/kr/app/id430282710";
    }
    
    
    
    
    
    if( tempIsKnownInstallUrl && nil != tempInstallUrl )
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"안 내" message:@"앱이 설치 되어 있지 않습니다.\n앱을 설치 하시겠습니까?" preferredStyle:UIAlertControllerStyleAlert];
            
            [alertController addAction:[UIAlertAction actionWithTitle:@"닫기" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                
            }]];
            
            [alertController addAction:[UIAlertAction actionWithTitle:@"설치" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                
                
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:tempInstallUrl]];
                
            }]];
            
            
            [[[[UIApplication sharedApplication] keyWindow] rootViewController] presentViewController:alertController animated:YES completion:^{
            }];
        });
    }
    else
    {
        ///  앱의 install url 확인 안됨.
        dispatch_async(dispatch_get_main_queue(), ^{
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"안 내" message:@"앱이 설치 되어 있지 않습니다." preferredStyle:UIAlertControllerStyleAlert];
            
            [alertController addAction:[UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                
            }]];
            
            
            [[[[UIApplication sharedApplication] keyWindow] rootViewController] presentViewController:alertController animated:YES completion:^{
            }];
        });
    }
}

/**
 * 링크에서 스토어Id를 추출
 */
- (NSString *)storedIdFrameLink:(NSString*) linkStr
{
    NSArray *linkComponent = [linkStr componentsSeparatedByString:@"/"];
    if (linkComponent && [linkComponent count] > 1)
    {
        return [linkComponent lastObject];
    }
    
    return nil;
}

/**
 * 앱카드 등록 링크를 받아 Itunes Store로 이동한다.
 * (앱 내 스토어로 이동, 이를 위해 link에서 마지막 app-id만을 파싱하여 가져온다)
 *
 * @param 이동할 링크
 */
- (void)goItunesStoreWithLink:(NSString *)link
{
    NSString *iTunesLink = [NSString stringWithFormat:@"itms-appss://itunes.apple.com/kr/app/apple-store/%@",
                            [self storeIdFromLink:link]];
    NSURL    *iTunesURL  = [NSURL URLWithString:iTunesLink];
    
    NSLog(@"iTunes Link(NEW): %@", iTunesLink);
    if ([[UIApplication sharedApplication] canOpenURL:iTunesURL])
    {
        [[UIApplication sharedApplication] openURL:iTunesURL];
    }
}

/**
 * 웹페이지 로딩 시작
 */
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}

/**
 * 웹페이지 로딩 종료
 */
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

/**
 * 웹페이지 로딩 중 오류
 */
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    NSLog(@"Load Fail - 내용: %@", [error localizedDescription]);
    NSLog(@"Load Fail - error 전체 내용: %@", error);
    
    // NSURLErrorDomain error -999 무시하기.
    if (error.code == NSURLErrorCancelled) return;
}

@end
