//
//  main.m
//  DanalPaycard
//
//  Created by 오동현 on 2016. 1. 15..
//  Copyright © 2016년 오동현. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
