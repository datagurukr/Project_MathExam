<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
</head>
<body>
<?php

	/*****************************************************
	   * �ٳ� �ſ�ī�� ������ǥ API
	*****************************************************/

	/******************************************************
	   * DN_RECEIPT_URL   : ������ǥ ��� URL
	******************************************************/
	$DN_RECEIPT_URL = "https://www.danalpay.com/receipt/creditcard/view.aspx";

	/*****************************************************
	   * �ٳ� �ſ�ī�� ������ǥ ��ȣȭ ����
	   * CPID  : �ٳ����� �ο��� �帰 CPID
	   * CRYPTOKEY  : �ٳ����� ������ �帰 �Ϻ�ȣȭ PW
	   * IVKEY : �Ϻ�ȣȭ�� ���Ǵ� Initial Vector ��(������)
	******************************************************/
	$CPID = "xxxxx";
	$CRYPTOKEY = "xxxxx";
	$IVKEY = "d7d02c92cb930b661f107cb92690fc83";

	function toEncrypt($tid, $amount){
		global $CRYPTOKEY;
		global $IVKEY;

		$CRYPTOKEY = hextobin($CRYPTOKEY);
		$IVKEY = hextobin($IVKEY);
		
		$data = "TID=" . $tid . "|" . "AMOUNT=" . $amount;
		// ������ |�� ����ؼ� TID�� AMOUNT�� �ϳ��� ���ڿ��� ����
		$data = addPKCS5($data);
		// pkcs7 padding

		$CIPHER = MCRYPT_RIJNDAEL_128;
		$MODE = MCRYPT_MODE_CBC;

		$encrypt_string = mcrypt_encrypt($CIPHER, $CRYPTOKEY, $data, $MODE, $IVKEY);

		$EncText = base64_encode($encrypt_string);
		$EncText = urlencode($EncText);

		return $EncText;
	}

	function addPKCS5( $str ){
		$stringsize = strlen( $str );
		$blocksize = mcrypt_get_block_size( MCRYPT_RIJNDAEL_128 , MCRYPT_MODE_CBC );

		$paddingsize = $blocksize - ( $stringsize % $blocksize );
		$paddingchar = chr($paddingsize);
		$str .= str_repeat( $paddingchar , $paddingsize);

		return $str;
	}

	function CallCreditAPI($data){
		global $DN_RECEIPT_URL;
		global $CPID;

		$REQ_STR = "?dataType=receipt";
		$REQ_STR = $REQ_STR . "&cpid=" . $CPID;
		$REQ_STR = $REQ_STR . "&data=" . $data;
		$REQ_STR = $DN_RECEIPT_URL . $REQ_STR;

		return $REQ_STR;
	}

	function hextobin($hexstr) 
	{ 
		$n = strlen($hexstr); 
		$sbin="";   
		$i=0; 
		while($i<$n) {       
			$a =substr($hexstr,$i,2);           
			$c = pack("H*",$a); 
			if ($i==0) {
				$sbin=$c;
			} else {
				$sbin.=$c;
			} 
			$i+=2; 
		} 
		return $sbin; 
	} 
?>

<?php
	/*****************************************************
	   ��� ����
	******************************************************/
	$tid = "xxxxx";
	$amount = "xxxxx";
	$EncData = toEncrypt($tid, $amount);

	echo("��ȣȭ�� ������ : ");
	echo($EncData);
	echo("<br>");

	$url = CallCreditAPI($EncData);
	echo("URL : ");
	echo($url);
	echo("<br>");

	echo("<a href=" . $url . ">������ǥ���</a>");

?>
</body>
</html>